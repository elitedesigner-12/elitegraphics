Place logo, poster, portfolio, profile, mockup and other website images here.
Example: assets/img/logo.png
